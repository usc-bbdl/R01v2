#include <iostream>
#include <conio.h>
#include <stdio.h>
#include <windows.h>
#include "servoControl.h"

int main() {
	servoControl a;
    a.goDefault();
}
